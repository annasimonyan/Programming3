// KERPARNER
// 0 datark vandak (#acacac)
// 1 kanach xot (#00A717) 
// 2 manushakaguyn xotaker (#4F2736)  
// 3 kapuyt sunk(#04E2B0)  
// 4 karmir gishatich(#D10303) 
var a;
a = prompt('input number');
a = parseInt(a);

var matrix = [];
for (var y = 0; y < a; y++) {
    matrix[y] = [];
    for (var x = 0; x < a; x++) {
        matrix[y][x] = Math.round(Math.floor(0, 1));
    }
}
function RandomMatrix(matrix,a)
{
    var i = 0;
    while (i < a * a / 3) {
        for (var y = 0; y < matrix.length; y++) {
            var idx1 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
            for (var x = 0; x < matrix[y].length; x++) {
                var idx2 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
                i++;
                break;
            }
    
            matrix[idx1][idx2] = 1;
    
        }
    }
    var i = 0;
    while (i < a / 3) {
        for (var y = 0; y < matrix.length; y++) {
            var idx1 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
            for (var x = 0; x < matrix[y].length; x++) {
                var idx2 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
                break;
            }
            if (matrix[idx1][idx2] == 0) {
                matrix[idx1][idx2] = 2;
                i++;
            }
    
    
        }
    }
    var i = 0;
    while (i <  a / 3) {
        for (var y = 0; y < matrix.length; y++) {
            var idx1 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
            for (var x = 0; x < matrix[y].length; x++) {
                var idx2 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
                break;
            }
            if (matrix[idx1][idx2] == 0) {
                matrix[idx1][idx2] = 3;
                i++;
            }
    
        }
    }
    var i = 0;
    while (i <  a / 3) {
        for (var y = 0; y < matrix.length; y++) {
            var idx1 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
            for (var x = 0; x < matrix[y].length; x++) {
                var idx2 = matrix.indexOf(matrix[Math.floor(Math.random() * matrix.length)]);
                i++;
                break;
            }
            if (matrix[idx1][idx2] == 0) {
                matrix[idx1][idx2] = 4;
                i++;
            }
        }
    }
    return matrix;
}



var side = 12;
var grassArr = [];
var sunk = [];
var xotaker = [];
var gishatich = [];

function setup() {
    frameRate(5);
    createCanvas(matrix.length * side, matrix.length * side);
    background('#acacac');

    matrix=RandomMatrix(matrix,a);
    console.log(matrix);

    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {
            if (matrix[y][x] == 1) {
                var gr = new Grass(x, y);
                grassArr.push(gr);

            }
            else if (matrix[y][x] == 2) {

                var xot = new Xotaker(x, y);
                xotaker.push(xot);

            }
            else if (matrix[y][x] == 3) {
                var vatSunk = new Sunk(x, y);
                sunk.push(vatSunk);

            }
            else if (matrix[y][x] == 4) {
                var p = new Gishatich(x, y);
                gishatich.push(p);

            }

        }

    }

}



function draw() {
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {

            if (matrix[y][x] == 1) {
                fill("#00A717");
                rect(x * side, y * side, side, side);
            }
            else if (matrix[y][x] == 2) {
                fill("#4F2736");
                rect(x * side, y * side, side, side);
            }
            else if (matrix[y][x] == 0) {
                fill("#acacac");
                rect(x * side, y * side, side, side);
            }
            else if (matrix[y][x] == 3) {
                fill("#04E2B0");
                rect(x * side, y * side, side, side);
            }
            else if (matrix[y][x] == 4) {
                fill("#D10303");
                rect(x * side, y * side, side, side);
            }
        }
    }

    for (var i in grassArr) {
        grassArr[i].bazmanal();

    }
    for (var j in sunk) {
        sunk[j].bazmanal();
    }

   
    for (var k in xotaker) {
        xotaker[k].utel();
        for (var i in grassArr) {
            if (grassArr[i].x == xotaker[k].x && grassArr[i].y == xotaker[k].y) {
                grassArr.splice(i, 1);
                break;
            }
        }
        for (var j in sunk) {
            if (sunk[j].x == xotaker[k].x && sunk[j].y == xotaker[k].y) {
                sunk.splice(j, 1);
                break;
            }
        }
    }

    for (var i in xotaker) {
        if (xotaker[i].energy == 10)
            xotaker[i].bazmanal();
        else if (xotaker[i].energy <= 0) {
            xotaker[i].satkel();
            xotaker.splice(i, 1);
            break;
        }


    }

    for (var k in gishatich) {
        gishatich[k].utel();
        for (var i in grassArr) {
            if (grassArr[i].x == gishatich[k].x && grassArr[i].y == gishatich[k].y) {
                grassArr.splice(i, 1);
                break;
            }
        }
        for (var j in sunk) {
            if (sunk[j].x == gishatich[k].x && sunk[j].y == gishatich[k].y) {
                sunk.splice(j, 1);
                break;
            }
        }
        for (var l in xotaker) {
            if (xotaker[l].x == gishatich[k].x && xotaker[l].y == gishatich[k].y) {
                xotaker.splice(l, 1);
                break;
            }
        }
    }

    for (var i in gishatich) {
        if (gishatich[i].energy >= 10)
            gishatich[i].bazmanal();
        else if (gishatich[i].energy <= 0) {
            gishatich[i].satkel();
            gishatich.splice(i, 1);
            break;
        }


    }

}

